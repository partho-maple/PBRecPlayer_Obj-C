#ifndef _SOHEL_H_
#define _SOHEL_H_

#define inline __inline

#endif